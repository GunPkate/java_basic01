
public class calculator {
	public static void main(String[] args) {
		System.out.println("1/2 = "+1/2);
		System.out.println("1.0/2.0 = "+1.0/2.0);
		System.out.println("(int)1.0/2 = "+(int)1.0/2);
		System.out.println("1/2+1/2 = "+(1/2+1/2));
		System.out.println("3/7 = "+(3/7));
		System.out.println("3%7 = "+(3%7));
		System.out.println("1/2+1/2 = "+(1/2+1/2));
	
		System.out.println("7/3 = "+(7/3));
		System.out.println("7%3 = "+(7%3));
		System.out.println("8/2 = "+(8/2));
		//System.out.println("8/0 = "+(8/0)); NaN
		System.out.println("8/0.0 = "+(8/0.0)); //infinity
		System.out.println("(double)1/2 = "+((double)1/2 )); //1.0/2.0
		System.out.println("(int)1.0/2.0 = "+((int)1.0/2.0 )); //1/2.0
		System.out.println("(int)1.0/2 = "+((int)1.0/2 )); //1/2
		
		
	}
}
