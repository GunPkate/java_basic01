import java.util.Scanner;

public class first {

	public static void main(String[] args) {
		int x;
		int y;
		x = 3;
		y = 6;
		System.out.println(x + y); //sysout ctrl + space
		
//		Scanner sc = new Scanner(System.in);
//		int k = sc.nextInt();
//		//k = 16;
//		if(k < 7) {
//			System.out.println("Hello");
//		}
//		else {
//			System.out.println("Good bye");
//		}
//		
		System.out.println(8/0);
	}

}
